import React, { useEffect, useMemo, useState } from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Label } from "./components/ui/label";
import Select from "./components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./components/ui/dialog";
import { Badge } from "./components/ui/badge";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { RefreshCw, Search, Settings, Trash2 } from "lucide-react";

/** Minimal two-page MVP (Markets + Portfolio) with a local UI kit. */

type AssetType = "crypto" | "stock";
type Asset = {
 id: string;
 type: AssetType;
 symbol: string;
 name: string;
 quantity: number;
 avgPrice: number;
 priceUSD?: number;
 lastUpdated?: number;
 meta?: any;
};
type SettingsState = { finnhubKey?: string };
type Coin = {
 id: string;
 symbol: string;
 name: string;
 image: string;
 current_price: number;
 market_cap: number;
 price_change_percentage_24h: number;
 price_change_percentage_7d_in_currency?: number;
 price_change_percentage_1h_in_currency?: number;
 total_volume: number;
};
type GlobalStats = {
 total_market_cap_usd?: number;
 market_cap_change_percentage_24h_usd?: number;
 btc_dominance?: number;
 active_cryptocurrencies?: number;
 markets?: number;
};

const LS_ASSETS_KEY = "tracker.assets.v1";
const LS_SETTINGS_KEY = "tracker.settings.v1";

function useLocalStorage<T>(key: string, initial: T) {
  const [state, setState] = useState<T>(() => {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : initial; } catch { return initial; }
  });
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(state)); } catch {} }, [key, state]);
  return [state, setState] as const;
}
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
function fmtUSD(n?: number) { if (n===undefined||Number.isNaN(n)) return "—"; return n.toLocaleString(undefined,{style:"currency",currency:"USD",maximumFractionDigits:2}); }
function fmtNum(n?: number) { if (n===undefined||Number.isNaN(n)) return "—"; return n.toLocaleString(); }
function pnlColor(v: number) { return v>0?"text-green-600":v<0?"text-red-600":"text-slate-500"; }

const GECKO_MAP: Record<string, string> = { BTC:"bitcoin", ETH:"ethereum", SOL:"solana", XRP:"ripple", ADA:"cardano", DOGE:"dogecoin", TON:"the-open-network", BNB:"binancecoin", AVAX:"avalanche-2", TRX:"tron", MATIC:"matic-network" };
async function resolveCrypto(symbol: string) {
  const sym = symbol.trim().toUpperCase();
  let id = GECKO_MAP[sym];
  if (!id) {
    try { const res = await fetch(`https://api.coingecko.com/api/v3/search?query=${encodeURIComponent(sym)}`); const data = await res.json(); const coin = data?.coins?.find((c: any)=>c?.symbol?.toUpperCase()===sym) || data?.coins?.[0]; if (coin) id = coin.id; } catch {}
  }
  if (!id) throw new Error("Crypto not found");
  let name = sym;
  try { const r = await fetch(`https://api.coingecko.com/api/v3/coins/${id}`); const d = await r.json(); name = d?.name || sym; } catch {}
  return { geckoId: id, name };
}
async function fetchCryptoPriceUSD(geckoId: string): Promise<number|undefined> {
  try { const res = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(geckoId)}&vs_currencies=usd`); const data = await res.json(); return data?.[geckoId]?.usd; } catch { return undefined; }
}
async function fetchGlobal(): Promise<GlobalStats> {
  try {
    const r = await fetch("https://api.coingecko.com/api/v3/global");
    const d = await r.json();
    const data = d?.data || {};
    return {
      total_market_cap_usd: data?.total_market_cap?.usd,
      market_cap_change_percentage_24h_usd: data?.market_cap_change_percentage_24h_usd,
      btc_dominance: data?.market_cap_percentage?.btc,
      active_cryptocurrencies: data?.active_cryptocurrencies,
      markets: data?.markets,
    };
  } catch { return {}; }
}
async function fetchCoins(page=1, per_page=50, search=""): Promise<Coin[]> {
  try {
    const url = new URL("https://api.coingecko.com/api/v3/coins/markets");
    url.searchParams.set("vs_currency","usd");
    url.searchParams.set("order","market_cap_desc");
    url.searchParams.set("per_page", String(per_page));
    url.searchParams.set("page", String(page));
    url.searchParams.set("sparkline","false");
    url.searchParams.set("price_change_percentage","1h,24h,7d");
    const res = await fetch(url.toString());
    const data: Coin[] = await res.json();
    if (!search) return data;
    const s = search.toLowerCase();
    return data.filter(c => c.name.toLowerCase().includes(s) || c.symbol.toLowerCase().includes(s));
  } catch { return []; }
}
async function fetchStockPriceUSD(symbol: string, finnhubKey?: string): Promise<number|undefined> {
  if (!finnhubKey) return undefined;
  try { const res = await fetch(`https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${encodeURIComponent(finnhubKey)}`); const d = await res.json(); return typeof d?.c === "number" ? d.c : undefined; } catch { return undefined; }
}
function genSparkline(base: number) {
  const out: {t:string;v:number}[] = []; let v = base;
  for (let i=9;i>=0;i--) { const dt=new Date(Date.now()-i*3600_000); const delta=(Math.random()-0.5)*(base*0.01); v=Math.max(0, v+delta); out.push({t:dt.toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}), v:+v.toFixed(2)}); }
  return out;
}

export default function App() {
  const [tab, setTab] = useState<"home"|"portfolio">("home");
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white p-4 md:p-6">
      <div className="mx-auto max-w-7xl space-y-4">
        <nav className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-xl bg-black" />
            <span className="text-xl font-semibold tracking-tight">MarketPulse</span>
          </div>
          <div className="flex items-center gap-2">
            <button className={`px-3 py-1.5 text-sm rounded-lg ${tab==="home"?"bg-black text-white":"bg-white border border-slate-200"}`} onClick={()=>setTab("home")}>Markets</button>
            <button className={`px-3 py-1.5 text-sm rounded-lg ${tab==="portfolio"?"bg-black text-white":"bg-white border border-slate-200"}`} onClick={()=>setTab("portfolio")}>Portfolio</button>
          </div>
        </nav>
        {tab === "home" ? <HomePage/> : <PortfolioPage/>}
      </div>
    </div>
  );
}

function HomePage() {
  const [global, setGlobal] = useState<GlobalStats>({});
  const [coins, setCoins] = useState<Coin[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");

  async function load() {
    setLoading(true);
    const [g, list] = await Promise.all([fetchGlobal(), fetchCoins(1, 100, search)]);
    setGlobal(g); setCoins(list); setLoading(false);
  }
  useEffect(() => { load(); const id=setInterval(load, 60_000); return ()=>clearInterval(id); }, []);
  useEffect(() => { const t=setTimeout(load, 300); return ()=>clearTimeout(t); }, [search]);

  return (
    <div className="space-y-6">
      <Card className="shadow-xs">
        <CardContent className="p-5">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
            <Metric label="Global Mkt Cap" value={fmtUSD(global.total_market_cap_usd)} change={global.market_cap_change_percentage_24h_usd}/>
            <Metric label="24h Change" value={(global.market_cap_change_percentage_24h_usd??0).toFixed(2)+'%'} change={global.market_cap_change_percentage_24h_usd}/>
            <Metric label="BTC Dominance" value={(global.btc_dominance??0).toFixed(1)+'%'} />
            <Metric label="# Cryptos" value={fmtNum(global.active_cryptocurrencies)} />
            <Metric label="# Markets" value={fmtNum(global.markets)} />
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col items-start justify-between gap-3 md:flex-row md:items-center">
        <h2 className="text-xl font-semibold tracking-tight">Top Cryptocurrencies by Market Cap</h2>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search (e.g. BTC, Solana)" className="pl-9 w-64"/>
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-slate-400"/>
          </div>
          <Button variant="outline" onClick={load} disabled={loading} className="gap-2">
            <RefreshCw className={`h-4 w-4 ${loading?"animate-spin":""}`}/> Refresh
          </Button>
        </div>
      </div>

      <Card className="shadow-xs">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[60px] text-right">#</TableHead>
                <TableHead>Coin</TableHead>
                <TableHead className="text-right">Price</TableHead>
                <TableHead className="text-right">1h%</TableHead>
                <TableHead className="text-right">24h%</TableHead>
                <TableHead className="text-right">7d%</TableHead>
                <TableHead className="text-right">Market Cap</TableHead>
                <TableHead className="text-right">Volume 24h</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {coins.length===0 && (
                <TableRow><TableCell colSpan={8} className="py-10 text-center text-sm text-slate-500">{loading?"Loading markets…":"No results"}</TableCell></TableRow>
              )}
              {coins.map((c, idx) => (
                <TableRow key={c.id} className="hover:bg-slate-50">
                  <TableCell className="text-right text-slate-500">{idx+1}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <img src={c.image} alt="" className="h-6 w-6 rounded-full"/>
                      <div className="flex items-baseline gap-2">
                        <span className="font-medium">{c.name}</span>
                        <span className="text-xs uppercase text-slate-500">{c.symbol}</span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">{fmtUSD(c.current_price)}</TableCell>
                  <TableCell className={`text-right ${pnlColor(c.price_change_percentage_1h_in_currency??0)}`}>{(c.price_change_percentage_1h_in_currency??0).toFixed(2)}%</TableCell>
                  <TableCell className={`text-right ${pnlColor(c.price_change_percentage_24h??0)}`}>{(c.price_change_percentage_24h??0).toFixed(2)}%</TableCell>
                  <TableCell className={`text-right ${pnlColor(c.price_change_percentage_7d_in_currency??0)}`}>{(c.price_change_percentage_7d_in_currency??0).toFixed(2)}%</TableCell>
                  <TableCell className="text-right">{fmtUSD(c.market_cap)}</TableCell>
                  <TableCell className="text-right">{fmtUSD(c.total_volume)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function Metric({label, value, change}:{label:string; value:any; change?:number}){
  const ch = typeof change === "number" ? change : undefined;
  return (
    <div className="rounded-2xl border bg-white p-4 shadow-xs">
      <div className="text-xs text-slate-500">{label}</div>
      <div className="mt-1 text-lg font-semibold">{value ?? "—"}</div>
      {ch !== undefined && (<div className={`text-xs ${pnlColor(ch)} mt-1`}>{ch>0?"▲":""}{ch<0?"▼":""} {ch.toFixed(2)}%</div>)}
    </div>
  );
}

function PortfolioPage() {
  const [assets, setAssets] = useLocalStorage<Asset[]>(LS_ASSETS_KEY, []);
  const [settings, setSettings] = useLocalStorage<SettingsState>(LS_SETTINGS_KEY, {});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string|null>(null);
  const [form, setForm] = useState({ type: "crypto" as AssetType, symbol: "", quantity: "", avgPrice: "" });

  const totals = useMemo(() => {
    let cost=0, value=0; for (const a of assets){ cost += a.quantity*a.avgPrice; value += a.quantity*(a.priceUSD??a.avgPrice);} return { cost, value, pnl: value-cost, pnlPct: cost?((value-cost)/cost)*100:0 };
  }, [assets]);

  async function refreshPrices(){
    setLoading(true); setError(null);
    try {
      const updated: Asset[] = [];
      for (const a of assets){
        let price: number|undefined;
        if (a.type === "crypto"){
          const geckoId = a.meta?.geckoId || (await resolveCrypto(a.symbol)).geckoId;
          price = await fetchCryptoPriceUSD(geckoId);
          updated.push({ ...a, priceUSD: price ?? a.priceUSD, lastUpdated: Date.now(), meta: { ...(a.meta||{}), geckoId } });
        } else {
          price = await fetchStockPriceUSD(a.symbol, settings.finnhubKey);
          updated.push({ ...a, priceUSD: price ?? a.priceUSD, lastUpdated: Date.now() });
        }
        await sleep(200);
      }
      setAssets(updated);
    } catch(e:any){ setError(e?.message||"Failed to refresh"); }
    finally{ setLoading(false); }
  }
  useEffect(()=>{ refreshPrices(); const id=setInterval(refreshPrices, 60_000); return ()=>clearInterval(id); },[]);

  function removeAsset(id: string){ setAssets(assets.filter(a=>a.id!==id)); }
  async function addAsset(e: React.FormEvent){
    e.preventDefault(); setError(null);
    const symbol = form.symbol.trim().toUpperCase(); const quantity = parseFloat(form.quantity); const avgPrice = parseFloat(form.avgPrice);
    if (!symbol || !quantity || !avgPrice) { setError("Fill all fields correctly"); return; }
    let name = symbol; let meta: any = {};
    if (form.type === "crypto"){ try { const r = await resolveCrypto(symbol); name = r.name; meta.geckoId = r.geckoId; } catch {} }
    else if (settings.finnhubKey){ try { const r = await fetch(`https://finnhub.io/api/v1/stock/profile2?symbol=${encodeURIComponent(symbol)}&token=${encodeURIComponent(settings.finnhubKey!)}`); const d=await r.json(); if (d?.name) name=d.name; } catch {} }
    const newAsset: Asset = { id: `${form.type}:${symbol}:${Date.now()}`, type: form.type, symbol, name, quantity, avgPrice, priceUSD: undefined, lastUpdated: undefined, meta };
    setAssets([newAsset, ...assets]); setForm({ ...form, symbol:"", quantity:"", avgPrice:"" }); setTimeout(refreshPrices, 50);
  }

  const pieData = useMemo(()=>{
    const list = assets.map(a=>({ name: a.symbol, value: a.quantity*(a.priceUSD??a.avgPrice)}));
    const total = list.reduce((s,x)=>s+x.value,0); return total?list:[];
  }, [assets]);

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">Your Portfolio</h1>
          <p className="text-sm text-slate-500">Add assets, track live prices, and see your P/L at a glance.</p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2"><Settings className="h-4 w-4"/>Settings</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader><DialogTitle>Settings</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="finn">Finnhub API Key (for stocks)</Label>
                  <Input id="finn" value={settings.finnhubKey||""} onChange={(e)=>setSettings({...settings, finnhubKey:e.target.value})} placeholder="Paste your API key"/>
                  <p className="text-xs text-slate-500">Create a free key at finnhub.io to enable stock prices.</p>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Button variant="outline" onClick={refreshPrices} disabled={loading} className="gap-2">
            <RefreshCw className={`h-4 w-4 ${loading?"animate-spin":""}`}/> Refresh
          </Button>
        </div>
      </header>

      <Card className="shadow-xs">
        <CardContent className="p-4">
          <form onSubmit={addAsset} className="grid grid-cols-1 gap-3 md:grid-cols-12 md:items-end">
            <div className="md:col-span-2">
              <Label>Type</Label>
              <Select value={"crypto"} onValueChange={()=>{}} options={[{value:"crypto", label:"Crypto"},{value:"stock", label:"Stock"}]} />
            </div>
            <div className="md:col-span-3">
              <Label>Symbol</Label>
              <Input placeholder={"BTC"} value={form.symbol} onChange={(e)=>setForm({...form, symbol:e.target.value})}/>
            </div>
            <div className="md:col-span-2">
              <Label>Quantity</Label>
              <Input inputMode="decimal" placeholder="e.g. 1.25" value={form.quantity} onChange={(e)=>setForm({...form, quantity:e.target.value})}/>
            </div>
            <div className="md:col-span-3">
              <Label>Avg. buy price (USD)</Label>
              <Input inputMode="decimal" placeholder="e.g. 42000" value={form.avgPrice} onChange={(e)=>setForm({...form, avgPrice:e.target.value})}/>
            </div>
            <div className="md:col-span-2"><Button type="submit" className="w-full">Add</Button></div>
          </form>
          {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <Card className="lg:col-span-8 shadow-xs">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[120px]">Asset</TableHead>
                  <TableHead>Qty</TableHead>
                  <TableHead>Avg Price</TableHead>
                  <TableHead>Last Price</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead>P/L</TableHead>
                  <TableHead className="w-[140px]">Sparkline</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assets.length===0 && (<TableRow><TableCell colSpan={8} className="py-10 text-center text-sm text-slate-500">No assets yet. Add your first above.</TableCell></TableRow>)}
                {assets.map(a=>{
                  const last = a.priceUSD ?? a.avgPrice; const value = a.quantity*last; const cost = a.quantity*a.avgPrice; const pnl = value - cost; const spark = genSparkline(last);
                  return (
                    <TableRow key={a.id} className="hover:bg-slate-50">
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">{a.symbol}</span>
                          <span className="text-xs text-slate-500">{a.name}</span>
                          <div className="mt-1"><Badge variant="secondary" className="uppercase">{a.type}</Badge></div>
                        </div>
                      </TableCell>
                      <TableCell>{a.quantity}</TableCell>
                      <TableCell>{fmtUSD(a.avgPrice)}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{fmtUSD(a.priceUSD ?? undefined)}</span>
                          <span className="text-[10px] text-slate-500">{a.lastUpdated?new Date(a.lastUpdated).toLocaleTimeString():"—"}</span>
                        </div>
                      </TableCell>
                      <TableCell>{fmtUSD(value)}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className={`${pnlColor(pnl)} font-medium`}>{fmtUSD(pnl)}</span>
                          <span className={`text-xs ${pnlColor(pnl)}`}>{cost?((pnl/cost)*100).toFixed(2):"0.00"}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="h-16 w-36 pr-2">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={spark}>
                              <XAxis hide dataKey="t"/>
                              <YAxis hide domain={["auto","auto"]}/>
                              <Tooltip formatter={(v:any)=>fmtUSD(Number(v))} labelFormatter={(l)=>l}/>
                              <Line type="monotone" dataKey="v" dot={false} strokeWidth={2}/>
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </TableCell>
                      <TableCell><Button variant="ghost" className="border-0" onClick={()=>{ /* simple remove */ const next = assets.filter(x=>x.id!==a.id); setAssets(next); }}><Trash2 className="h-4 w-4"/></Button></TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="lg:col-span-4 space-y-6">
          <Card className="shadow-xs">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Portfolio</h3>
                <Badge variant={totals.pnl >= 0 ? "default" : "destructive"}>{totals.pnl >= 0 ? "Profit" : "Loss"}</Badge>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                <div className="rounded-xl bg-slate-100 p-3">
                  <div className="text-slate-500">Cost Basis</div>
                  <div className="text-lg font-medium">{fmtUSD(totals.cost)}</div>
                </div>
                <div className="rounded-xl bg-slate-100 p-3">
                  <div className="text-slate-500">Current Value</div>
                  <div className="text-lg font-medium">{fmtUSD(totals.value)}</div>
                </div>
                <div className="rounded-xl bg-slate-100 p-3 col-span-2">
                  <div className="text-slate-500">P/L</div>
                  <div className={`text-xl font-semibold ${pnlColor(totals.pnl)}`}>{fmtUSD(totals.pnl)} <span className="text-sm">({totals.pnlPct.toFixed(2)}%)</span></div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-xs">
            <CardContent className="p-4 text-sm text-slate-600">
              <h4 className="mb-2 font-semibold text-slate-900">Tips</h4>
              <ul className="list-disc space-y-1 pl-5">
                <li>Crypto prices use CoinGecko – no key needed.</li>
                <li>For stocks, add a free Finnhub API key in Settings to enable stock prices.</li>
                <li>All data is stored locally in your browser (no server).</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
