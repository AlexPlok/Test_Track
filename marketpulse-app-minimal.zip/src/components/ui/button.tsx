import React from 'react'
type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'default'|'outline'|'ghost', size?: 'default'|'icon' }
export const Button: React.FC<Props> = ({ variant='default', size='default', className='', ...props }) => {
  const base = 'inline-flex items-center justify-center rounded-2xl px-4 py-2 text-sm font-medium transition border';
  const variants = {
    default: 'bg-black text-white border-black hover:opacity-90',
    outline: 'bg-white text-slate-900 border-slate-300 hover:bg-slate-50',
    ghost: 'bg-transparent border-transparent hover:bg-slate-100'
  } as const;
  const sizes = { default: '', icon: 'p-2 aspect-square' } as const;
  return <button className={`${base} ${variants[variant]} ${sizes[size]} ${className}`} {...props} />;
}
export default Button
