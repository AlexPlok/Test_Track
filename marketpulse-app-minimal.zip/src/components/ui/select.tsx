import React from 'react'
type Opt = { value: string, label: string }
type Props = { value: string, onValueChange: (v:string)=>void, options: Opt[], className?: string }
export const Select: React.FC<Props> = ({ value, onValueChange, options, className='' }) => (
  <select className={`h-9 rounded-xl border border-slate-300 bg-white px-3 text-sm outline-none focus:ring-2 focus:ring-slate-200 ${className}`}
          value={value} onChange={e=>onValueChange(e.target.value)}>
    {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
  </select>
)
export default Select
