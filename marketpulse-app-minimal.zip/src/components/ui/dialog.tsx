import React from 'react'
export const Dialog: React.FC<{children:React.ReactNode}> = ({ children }) => <>{children}</>

export const DialogTrigger: React.FC<{asChild?:boolean, children:React.ReactNode}> = ({ children }) => <>{children}</>

export const DialogContent: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className='', ...props }) => (
  <div className={`mt-3 rounded-2xl border border-slate-200 bg-white p-4 ${className}`} {...props} />)

export const DialogHeader: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className='', ...props }) => (<div className={`mb-2 ${className}`} {...props} />)

export const DialogTitle: React.FC<React.HTMLAttributes<HTMLHeadingElement>> = ({ className='', ...props }) => (<h3 className={`text-base font-semibold ${className}`} {...props} />)

