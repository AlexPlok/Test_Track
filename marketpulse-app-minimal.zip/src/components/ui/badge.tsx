import React from 'react'
type Props = { children: React.ReactNode, variant?: 'default'|'destructive'|'secondary', className?: string }
export const Badge: React.FC<Props> = ({ children, variant='default', className='' }) => {
  const styles = {
    default: 'bg-slate-900 text-white',
    destructive: 'bg-red-600 text-white',
    secondary: 'bg-slate-100 text-slate-700 border border-slate-200'
  } as const;
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${styles[variant]} ${className}`}>
    {children}
  </span>
}
