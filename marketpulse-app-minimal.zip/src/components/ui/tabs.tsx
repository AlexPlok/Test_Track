import React from 'react'
export const Tabs = ({ value, onValueChange, children }:{value:string, onValueChange:(v:string)=>void, children:React.ReactNode}) => <div>{children}</div>
export const TabsList: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className='', ...props }) => (
  <div className={`inline-flex rounded-xl border border-slate-200 bg-white p-1 ${className}`} {...props} />
)
export const TabsTrigger = ({ value, children, onClick }:{value:string, children:React.ReactNode, onClick?:()=>void}) => (
  <button onClick={onClick} className={`px-3 py-1.5 text-sm rounded-lg data-[active=true]:bg-black data-[active=true]:text-white`} data-active={false} data-value={value}>
    {children}
  </button>
)
