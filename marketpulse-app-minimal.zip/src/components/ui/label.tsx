import React from 'react'
export const Label: React.FC<React.LabelHTMLAttributes<HTMLLabelElement>> = ({ className='', ...props }) => (
  <label className={`text-xs text-slate-500 ${className}`} {...props} />
)
export default Label
